package com.interview.jsp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class FileParser {
	public ArrayList<HashMap<String, String>> parse(String fileName) throws Exception {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		String pattern = "\\d{4}-\\d{2}-\\d{2}.*\\d{2}:\\d{2}:\\d{2},\\d{3}\\s+(ERROR|INFO|DEBUG)\\s+\\[(\\S+):(\\S+)(:(\\S+))?\\]\\s+(.+)";
		String line;
		ArrayList<HashMap<String, String>> data = new ArrayList<>();
		String temp[];
		while ((line = br.readLine()) != null) {
			
			if (line.matches(pattern)) {
				//System.out.println(line);
				HashMap<String, String> hm = new HashMap<>();
				int i = 0;				
				temp = line.split("\\s+");
				hm.put("date", temp[0]+temp[1]);
				hm.put("log_level", temp[2]);
				String ufs[] = temp[3].split(":");	
				String obr[] = ufs[0].split("\\[");
				hm.put("user", obr[1]);
					
				if (ufs.length == 2) {					
					hm.put("subfunction", "undefined");
				}
				else {
					String cbr[] = ufs[2].split("]");
					hm.put("subfunction", cbr[0]);
				}
				if (ufs.length == 2) {
					String cbr[] = ufs[1].split("]");
					hm.put("function", cbr[0]);
				}
				else {
					hm.put("function", ufs[1]);
				}
				
				String tempMsg[] = line.split("]");															
				hm.put("message", tempMsg[1]);
				/*for (int j = 0; j < temp.length; j++) {
					System.out.println(temp[j]);
				}*/
				Iterator it = hm.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        //System.out.println(pair.getKey() + " = " + pair.getValue());
			    }
				data.add(hm);
			}	
		}		        
		
		return data;
	}	
}
