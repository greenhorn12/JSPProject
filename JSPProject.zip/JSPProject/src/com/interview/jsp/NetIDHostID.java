package com.interview.jsp;


public class NetIDHostID {
	
	public  String[] ipAddressNetMask (String ipAddress, String netMask) {
		String ids[] = getNetIDHostID(ipAddress, netMask);
		return ids;
	}
	
	public  String[] ipAddressNetMask (String ipAddressNetMask) {
		String temp[] = ipAddressNetMask.split("/");
		int mask = Integer.parseInt(temp[1]);
		int max = mask / 8;
		StringBuilder sb = new StringBuilder();
		
		if (mask % 8 == 0) {
			int i;
			for (i = 0; i < max; i++) {
				if (i != 3) {
					sb.append("255.");
				}
				else {
					sb.append("255");
				}
			}
			for (int j = i; j < 4; j++) {
				if (j != 3) {
					sb.append("0.");
				}
				else {
					sb.append("0");
				}
			}
			String ids[] = getNetIDHostID(temp[0], sb.toString());
			return ids;
		}
		int i;
		for (i = 0; i < max; i++) {
			sb.append("255.");
		}
		int offset = mask % 8;
		StringBuilder octet = new StringBuilder();
		for (int a = 0; a < offset; a++) {
			octet.append("1");
		}
		for (int b = offset; b < 8; b++) {
			octet.append("0");
		}
		sb.append(Integer.parseInt(octet.toString(), 2));
		if (i != 3) {
			sb.append(".");			
		}
		else {
			String ids[] = getNetIDHostID(temp[0], sb.toString());
			return ids;
		}
		for (int j = max+1; j < 4; j++) {
			if (j != 3) {
				sb.append("0.");
			}
			else {
				sb.append("0");
			}
		}
		String ids[] = getNetIDHostID(temp[0], sb.toString());
		return ids;
	}
	
	public  String[] getNetIDHostID (String ipAddress, String netMask) {
		String ids[] = new String[2];
		System.out.println("netMas is "+netMask);
		String ipOctets[] = ipAddress.split("\\.");
		String subnetOctets[] = netMask.split("\\.");
		StringBuilder ipSB = new StringBuilder();
		int temp;
		for (int i = 0; i < 4; i++) {			
			ipSB.append(Integer.parseInt(ipOctets[i]) & Integer.parseInt(subnetOctets[i]));
			if (i!=3)
				ipSB.append(".");
		}
		ids[0] = ipSB.toString();
		String inverseSubnet;
		StringBuilder sbInverseSubnet = new StringBuilder();
		int i;
		for (i = 0; i < 4; i++) {
			//System.out.println("i is "+i+" subnetOctets[i] is "+subnetOctets[i]);
			if (subnetOctets[i].equals("255")) {
				if (i != 3) {
					sbInverseSubnet.append("0.");
				}
				else {
					sbInverseSubnet.append("0");
				}
			}
			else {
				//System.out.println("breaking when i is "+i+" and subnetOctets[i] is "+subnetOctets[i]);
				break;
			}
		}
		if (i != 4) {			
			if (subnetOctets[i].equals("0")) {
				for (int b = i; b < 4; b++) {
					//System.out.println("b is "+b);
					if (b != 3)
						sbInverseSubnet.append("255.");
					else
						sbInverseSubnet.append("255");
				}
			}
			else {
				String mixedOctet = Integer.toBinaryString(Integer.parseInt(subnetOctets[i]));
				StringBuilder mixedOctetsb = new StringBuilder();
				for (int a = 0; a < 8; a++) {
					if (mixedOctet.charAt(a) == '1') {
						mixedOctetsb.append("0");
					}
					else {
						mixedOctetsb.append("1");
					}
				}
				sbInverseSubnet.append(Integer.parseInt(mixedOctetsb.toString(), 2));
				//System.out.println("mixed one is "+Integer.parseInt(mixedOctetsb.toString(), 2));
				if (i < 3) {
					sbInverseSubnet.append(".");
				}
				for (int j = i+1; j < 4; j++) {
					//System.out.println("final for loop.. j is "+j+" and subnetOctets[j] is "+ subnetOctets[j]);
					if (subnetOctets[j].equals("0")) {
						if (j != 3) {
							sbInverseSubnet.append("255.");
						}
						else {							
							sbInverseSubnet.append("255");
						}
					}
				}
			}		
		}
		
		inverseSubnet = sbInverseSubnet.toString();
		//System.out.println("inverse is "+inverseSubnet);
		String inverseSubnetOctets[] = inverseSubnet.split("\\.");
		StringBuilder sbHostID = new StringBuilder();
		for (int x = 0; x < 4; x++) {
			//System.out.println("ipoct is "+ipOctets[x]+" and invsuboct is "+inverseSubnetOctets[x]);
			sbHostID.append(Integer.parseInt(ipOctets[x]) & Integer.parseInt(inverseSubnetOctets[x]));
			if (x != 3)
				sbHostID.append(".");
		}
		ids[1] = sbHostID.toString();
		System.out.println("ids0 is "+ids[0]+" ids1 is "+ids[1]);
		return ids;
	}
		

}